1. Copy testcase_filename.txt and input_filename.txt to server folder.
initially testcase_revArr.txt and input_revArr.txt is inside server folder for revArr.cpp

> If file already present in server, error message will be send to client.
> NOTE: delete previous test program file uisng dele before using codejud on same program again.

> compilation.txt is created only if there is compilation error at server side.

> output_filename.txt is created at server side if execution of code is successful.

> Size limit: 512 KB (can be increased by changing "#define SIZE 512000" in code)

> Sample files are provided in the client space.

> Server folder serves as server space to avoid file collision.

> "list.txt" is created by server.cpp to store and maintain live file names, only files sent by client will be shown by LIST command.

Thanks!


